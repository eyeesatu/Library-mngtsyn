<?php
include "connection.php";
include "navbar.php";

?>

<!DOCTYPE html>
<html>
    <head>
        <title>Admin-login</title>
        <link rel="stylesheet"type="text/css"href="style.css">
        <meta charset="utf-8">
        <meta name="viewpoint"content="widht=device-width,initial-scale=1">
             <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
             <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
             <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<style type="text/css">

	
	
section  
            {
             margin-top: -22px;
            }
.log_img
     {
            height: 1000px;
            margin-top:0px ;
            background-image: url("images/login.png"); 
     }
.box1
     {
		margin-top:-25px;
        height: 480px;
        width: 400px;
        background-color:darkslategray;
		margin: 70px auto;
        opacity: .7;
        color: white;
        padding: 20px;
        border-radius: 15px;
		border:double;
	}
#lb
	{
		color: white;
		text-align: center;
		font-family: georgia;
		font-size: 35px;
		text-transform: uppercase;
	}
#usr
	{
		text-align: center;
		font-family: georgia;
		font-size: 35px;
		text-decoration: underline;
	}
#ln
	 {
		 background-color: aqua;
		 height: 30px;
		 width: 100px;
		 color: black;
	 }
/*.alert alert-warning
{
	width: 400px;
	margin-left:300px;
}
*/

	   
</style>
		
		
		
		<script type="text/javascript">
		                 function formvalidate()
		                     {
		                       	var user=document.getElementById("us");
								var password=document.getElementById("lg");
		                      	var txt=/^[A-Za-z]+$/;
								var phn=/^\d{10}$/;
	//user name validation
		                       	if( user.value=="")
				                    {
			 	                     	alert("please write your user name");
					                    return false;
				                     }
								 if( user.value.length<2)
									 {
										 alert("user name shoud contian at least 4 charcters");
					                     return false;
									 }
								 if( !(user.value.match(txt)))
									{
									  alert("user name can't accept numbers");
									  return false;
								    }
		//password  validation
								  if( password.value=="")
				                    {
			 	                     	alert("please insert your password");
					                    return false;
				                    }
						
	                         }
			</script>
</head>
<body>
        
 <section>
            <div class="log_img">
                <br>
            <div class="box1">
                <h1 id="lb">Library Management System</h1>
                <h1 id="usr">Admin Login Form</h1><br>
        <form name="Login"action=""method="post">
                <div class="login">
                 <input  class ="form-control"style="font-size: 20px;"type="text"name="username"placeholder="User name"id="us"><br>
                 <input class ="form-control"style="font-size: 20px;"type="password"name="password"placeholder="password"id="lg"><br>
                 <input class ="btn btn-defoult"type="submit"name="submit" value="Log-in"onclick="formvalidate();"id="ln"><br><br>
            </div>
        </form>
                <p style="color:white; padding-left: 15px;">
                    <a style="color:white" href="">Forget Password?</a>&nbsp;&nbsp;&nbsp;&nbsp;
                    New to this website?<a style="color:white"href="registration.php"> Sign Up
                    </a>
                </p>
            </div>

               </div>
 </section>

        <?php

		if(isset($_POST['submit']))
		{
			$count=0;
			$res=mysqli_query($db,"SELECT * FROM `admin`WHERE username='$_POST[username]' && password='$_POST[password]';");
			
			$count=mysqli_num_rows($res);

			if($count==0)
			{
				?>
				<!--
                    <script type="text/javascript">
						alert("The username and password doesn't match.");
					</script>
			
			-->
			<div class="alert alert-danger" style="width: 700px; margin-left:620px; background-color:#700505;">
				<strong>The username and password doesn't match.</strong>
			</div>
			   
				<?php
			}
			 
			else
			{
			  $_SESSION['login_user'] =$_POST['username'];
				?>
                 <script type="text/javascript">
						window.location="student.php"
					</script>
				<?php
			}
		}


		?>
        
</body>
</html>