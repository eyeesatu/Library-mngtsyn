<?php
include "connection.php";
include "navbar.php";
?>

<!DOCTYPE html>
<html>
 <head>

        <title>Admin registration</title>
        <link rel="stylesheet"type="text/css"href="style.css">
        <meta charset="utf-8">
        <meta name="viewpoint"content="widht=device-width,initial-scale=1">
             <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
             <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
             <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

    </head>

 <body>
 <style type="text/css">
	 p
	 {
		 color: aliceblue;
		 font-family: georgia;
		 font-size: 20px;
	 }
        section  
            {
               margin-top: -22px;
            }
.reg_img
     {
            height: 850px;
            margin-top:0px ;
            background-image: url("images/reg.png"); 
     }
#a
	 {
		 font-family: serif;
		 font-size: 25px;
		
	 }
#b
	 {
		 font-family: serif;
		 font-size: 25px;
		 
		 text-decoration: underline;
	 }
.box2
	 {
		 background-color:darkslategray;
		 border:double;
		 height: 720px;
		 opacity: .7;
		 margin: 70px auto;
         opacity: .7;
         color: white;
         margin-top: -0px;
         border-radius: 15px;
		 
	 }
#sn
	 {
		 background-color: aqua;
		 height: 30px;
		 width: 100px;
		 color: black;
	 }

 </style> 
	        <script type="text/javascript">
		                    function formvalidate()
		                        {
		
		                        var fname=document.getElementById("fn");
								var lname=document.getElementById("ln");
								var user=document.getElementById("un");
								var password=document.getElementById("pss");
								var roll=document.getElementById("rn");
								var email=document.getElementById("eml");
								var phone=document.getElementById("pn");
								 
		                      	 var txt=/^[A-Za-z]+$/;
								 var phn=/^\d{10}$/; 
	    //frist name validation
		                       	if( fname.value=="")
				                    {
			 	                     	alert("please write your Frist name");
					                    return false;
				                     }
								 if( fname.value.length<2)
									 {
										 alert("Frist name shoud contian at least 6 charcters");
					                     return false;
									 }
								 if( !(fname.value.match(txt)))
									{
									    alert("First name can't accept numbers");
										return false;
									}
		// last name valiadtion
								 if( lname.value=="")
				                    {
			 	                     	alert("please write your last  name");
					                    return false;
				                     }
								 if( lname.value.length<2)
									 {
										 alert("Last name shoud contian at least 6 charcters");
					                     return false;
									 }
								 if( !(lname.value.match(txt)))
									{
									    alert("last name can't accept numbers");
										return false;
									}
		  //user name validation
		                       	if( user.value=="")
				                    {
			 	                     	alert("please write your user name");
					                    return false;
				                     }
								 if( user.value.length<2)
									 {
										 alert("user name shoud contian at least 4 charcters");
					                     return false;
									 }
								 if( !(user.value.match(txt)))
									{
									  alert("user name can't accept numbers");
									  return false;
								    }
			  //password validation
								  if( password.value=="")
				                    {
			 	                     	alert("please insert your password");
					                    return false;
				                     }
			//roll number validation
								  if( roll.value=="")
				                    {
			 	                     	alert("please insert your roll number");
					                    return false;
				                     }
		     //email validation
								 if( email.value=="")
				                    {
			 	                     	alert("please write your email");
					                    return false;
				                     }
								 
								 
								 if( email.value.indexOf("@gmail")<0)
				                    {
			 	                     	alert("please write your corrct Email address");
					                    return false;
				                     }

			//phone number validation
								 	 if(phone.value.length!=10)
									 {
										 alert("please write your correct phone numbers");
					                     return false;
									 } 
								if( !(phone.value.match(phn)))
									{
									    alert("phone no can't accept charcter");
										return false;
									}
								
		                      }
	                 </script>
	 
</head>
<body>

 <section>
          <div class="reg_img">
             <br>
          <div class="box2">
                    <h1 style="text-align:center;font-size:35px;"id="a">Library Management System</h1>
			        <h1 style="text-align:center;font-size:25px;"id="b">Admin Registration Form</h1>
                <form name="Registration"action=""method="post">
                    <br>
                    <div class="login">
                     <input class ="form-control"style="font-size: 20px;"type="text"name="fristname"placeholder="frist name"required=""id="fn"><br>
                     <input class ="form-control"style="font-size: 20px;"type="text"name="lastname"placeholder="last name"required=""id="ln"><br>
                     <input class ="form-control"style="font-size: 20px;"type="text"name="username"placeholder="User name"required=""id="un"><br>
                     <input  class ="form-control"style="font-size: 20px;"type="password"name="password"placeholder="password"required=""id="pss"><br>
                     <input  class ="form-control"style="font-size: 20px;"type="text"name="email"placeholder="Email"required=""id="eml"><br>
					 <input  class ="form-control"style="font-size: 20px;"type="text"name="contact"placeholder="phone number"required=""id="pn"><br>
                     <input class ="btn btn-defoult"type="submit"name="submit" value="sign-up"onclick="formvalidate();"id="sn"><br><br><br>
						
						<p><a href ="vw.php">SEE ALL REGISTERD USERS</p></a>
					    <p><a href ="vws.php">SEE ALL REGISTERD ADMINS</p></a>
                    
                </div>
                </form>

                </div>

               </div>
</section>
<?php
   
   if(isset($_POST['submit']))
   {
      mysqli_query($db,"INSERT INTO `admin` VALUES('','$_POST[fristname]','$_POST[lastname]','$_POST[username]','$_POST[password]','$_POST[email]','$_POST[contact]');");
	  ?>
	  <script type="text/javascript">
		  alert(" You Are Registerd Succesfully");
		  </script>
	  <?php
  }
	   
?>

</body>
</html>