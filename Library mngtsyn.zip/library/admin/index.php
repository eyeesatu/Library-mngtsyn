<?php
  session_start();
?>
<!DOCTYPE html>
<html>
    <head>
        <title>online library management system</title>
        <link rel="stylesheet"type="text/css"href="style.css">
        <meta charset="utf-8">
        <meta name="viewpoint"content="widht=device-width,initial-scale=1">
<style type="text/css">
	
	
nav{
           float: right; 
           word-spacing: 30px;
           padding: 10px;
        }
nav li{
         display:inline-block;  
         line-height: 80px;
	   
        }
header
	{
		background-color: dodgerblue;
		color: black;
		height: 120px;
        opacity: .5px;
		
		
	}
footer
	{
		background-color: dodgerblue;
		color: black;
	}
h1
	{
		font-size: 25px;
		font-family: georgia;
		
	}
#hm
	{
		color: white;
		font-size: 20px;
	}
#bk
	{
		color: black;
		font-size: 20px;
	}
#st
	{
		color: white;
		font-size: 20px;
	}
#fd
	{
		color: black;
		font-size: 20px;
	}
nav ul li
	{
    list-style: none ;
    display: inline;
    text-transform: uppercase;
    font-weight: bold;
	color: black;
	}
nav li a:hover
  {
    color: blue;
    height: 20px;
    background-color: green;
	padding-top: 10px;
  }
.box
	{
		background-color: darkblue;
		opacity: .7px;
	}
	
section .sec_img
        {
            height: 700px;
            margin-top:0px ;
            background-image: url("images/homeee.png");
        }
	
</style>
    </head>
  <body>
     <div class="wrapper ">
            
      <header>
            <div class="logo">
                <img src="">
                <h1 style="color:white;"> BHU ONLINE LIBRARY MANGEMENT SYSTEM </h1>
           </div>
		  
		  <?php
		      if(isset($_SESSION['login_user']))
			  {
				  
		       ?>
				 <nav>
                    <ul>
                        <b><li><a href="index.php"id="hm">HOME</a></li></b>
                        <b><li><a href="books.php"id="bk">BOOKS</a></li><b>
                        <b><li><a href="feedback.php"id="fd">FEEDBACK </a></li><b>
						<b><li><a href="logout.php"id="st">LOGOUT</a></li><b>
                    </ul>
                </nav>
	         <?php
 
			  }
		  else
		  {
			?>
				<nav>
                    <ul>
                        <b><li><a href="index.php"id="hm">HOME</a></li></b>
                       
                        <b><li><a href="admin_login.php"id="st">ADMIN-LOGIN</a></li><b>
                        
                    </ul>
                </nav>
			  
		  <?php
		  }
		  
		  ?>
		
             
      </header>
 <section>

    <div class="sec_img">
    <br><br>
    <div class="box">
        <br><br>
        <h1 style="text-align:center;font-size:30px;">WELCOME TO BHU LIBRARY MANAGEMENT SYSTEM </h1><br><br>
       
        <h1 style="text-align:center;font-size:25px">24 Hours Available</h1><br>
    </div>
     </div>
     
 </section>
            
               <footer>
                    <p style="color:white">
                           <br>
                       Email:&nbsp; online.library@gmail.com<br>
                       Mobile:&nbsp;+251964395101<br>
                       Mobile:&nbsp;+251949537979<br>
                       Mobile:&nbsp;+251937314562<br>

                      </p>
               </footer>
    </div>
    </body>
</html>