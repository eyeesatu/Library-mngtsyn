<?php

include_once 'connection.php';
if(isset($_GET['id']))
{
	$idn=$_GET['id'];
	$deleteq="DELETE  FROM admin where id='$idn'";
	$runsqr=mysqli_query($db,$deleteq);
	
	
	if($runsqr)
	{
		header("location:vws.php");
	}
	else
	{
		print ("User isn't deleted");
	}
	
}




?>