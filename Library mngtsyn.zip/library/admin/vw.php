<style type="text/css">
body,td,th {
    font-size: 18px;
}
</style>
<p>List of users</p>
<table width="1588" border="1">
  <tbody>
    <tr bgcolor="gray">
	  <td width="267">Id</td>
      <td width="267">Frist name</td>
      <td width="353">Last name</td>
      <td width="339">Username</td>
      <td width="315">Password</td>
	  <td width="315">Roll</td>
	  <td width="339">Email</td>
      <td width="280">Phone number</td>
		<td width="280" colspan="2">Action</td
    </tr>
	  <?php
	  include_once 'connection.php';
	  $selectq="Select * from student";
	  $runq=mysqli_query($db,$selectq);
	  $data=mysqli_num_rows($runq);
	  if($data>0)
	  {
		  while($x=mysqli_fetch_assoc($runq))
		  {
			  echo "
	           <tr bgcolor='lightblue'>
			   <td>".$x['id']."</td>
			    <td>".$x['fristname']."</td>
				<td>".$x['lastname']."</td>
				<td>".$x['username']."</td>
				<td>".$x['password']."</td>
				<td>".$x['roll']."</td>
				<td>".$x['email']."</td>
				<td>".$x['contact']."</td>
				<td bgcolor='red'><a href='updt.php?contact=".$x['contact']." '>Edit</a></td>
				<td bgcolor='green'><a href='deletes.php?id=".$x['id']." '>Delete</a></td>
				
				
			   </tr>
			  ";
		  }
	  }
	  
	  ?>
<tr>
	<td> <a href="regst.php">Add users</a></td>
</tr>
  </tbody>
</table>
<p>&nbsp;</p>