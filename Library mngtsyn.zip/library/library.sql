-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 04, 2023 at 10:17 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.0.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `library`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(100) NOT NULL,
  `fristname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `contact` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `fristname`, `lastname`, `username`, `password`, `email`, `contact`) VALUES
(23, 'Mihretu', 'Kebede', 'mirekebe', '1234', 'mire@gmail.com', '0916746320');

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `bid` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `authors` varchar(100) NOT NULL,
  `edition` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  `quantity` int(100) NOT NULL,
  `department` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`bid`, `name`, `authors`, `edition`, `status`, `quantity`, `department`) VALUES
('1', 'principal of electronics', 'v.k. mehta,rohit.metha', '3rd', 'Available', 5, 'EEE'),
('2', 'The complete reference c++', 'Herbert schildt', '4th', 'Available', 2, 'CSE'),
('3', 'Data structures', 'seymour Lipschutz', '4th', 'Available', 5, 'ECE'),
('4', 'Fundamental software security', 'Hztv', '4th', 'Available', 10, 'Softwar engineering'),
('5', 'Microprocessor and assembly language', 'hyv.li', '3rd', 'Unavailable', 5, 'Software engineering'),
('6', 'Fundamental database', 'hgytol', '4th', 'Available', 25, 'SWE'),
('7', 'Software tools and practice', 'beholinkec', '7th', 'Available', 9, 'CSE'),
('8', 'Web design and programming', 'asaminew', '6th', 'Available', 4, 'computer science'),
('9', 'Internet programming', 'fasjdk', '3rd', 'Unavailable', 2, 'Information System'),
('10', 'Requirement Engineering', 'sdthydth', '5th', 'Available', 31, 'Software engineering');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(50) NOT NULL,
  `commnet` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `commnet`) VALUES
(1, 'when the new books are relesed ?');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `id` int(50) NOT NULL,
  `fristname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `roll` int(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `contact` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`id`, `fristname`, `lastname`, `username`, `password`, `roll`, `email`, `contact`) VALUES
(25, 'Selemawit', 'Abera', 'sellove', '25897', 10, 'sel@gmail.com', 916746320),
(26, 'yonas', 'asmare', 'yon', '456987', 124, 'yon@gmail.com', 939439296),
(27, 'Fenet', 'Getachew', 'fenko', '0147', 5, 'feni@gmail.com', 956847563),
(28, 'Temam', 'Husen', 'tamehuse', '0147', 123, 'tame@gmail.com', 926462133),
(30, 'Fenet', 'Getachew', 'fenko', '1245', 6325, 'feni@gmail.com', 956847563),
(31, 'Meklit', 'Kidanu', 'makilove', '0147', 123, 'mak@gmail.com', 924156879),
(34, 'DEGAGA', 'TADESSE', 'DEG', '12345678', 23, 'degagatadesse@gmail.com', 2147483647),
(35, 'Gadisa', 'Marga', 'gad', '1245', 12, 'gad@gmail.com', 912365478),
(36, 'FENET', 'GETACHEW', 'FENI', '2345', 0, 'FE@.COM', 2147483647),
(38, 'tamam', 'husen', 'tam', '1245', 14, 'tam@gmail.com', 912589632);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
